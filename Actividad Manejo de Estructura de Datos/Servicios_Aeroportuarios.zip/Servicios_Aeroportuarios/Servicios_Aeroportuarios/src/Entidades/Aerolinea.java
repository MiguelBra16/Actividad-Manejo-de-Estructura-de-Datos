package Entidades;

import java.util.ArrayList;

public class Aerolinea {

    private String nombreAerolinea;
    public ArrayList<Vuelo> lVuelos;

    public Aerolinea(String nombreAerolinea) {
        this.nombreAerolinea = nombreAerolinea;
        this.lVuelos = new ArrayList<>();
        
    }

    //Metodos
    public void agregarVuelo(Vuelo vuelo) {
        this.lVuelos.add(vuelo);
    }

    //Getters
    public String getNombreAerolinea() {
        return nombreAerolinea;
    }

    public ArrayList<Vuelo> getlVuelos() {
        return lVuelos;
    }

    //Setters
    public void setNombreAerolinea(String nombreAerolinea) {
        this.nombreAerolinea = nombreAerolinea;
    }

}
