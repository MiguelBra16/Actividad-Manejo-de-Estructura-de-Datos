package Entidades;

public class Vuelo {

    private String numVuelo, aerolinea, paisProcendencia, cantPasajeros, serviciosUtilizados, costoVuelo;

    public Vuelo(String numVuelo, String aerolinea, String paisProcendencia, String cantPasajeros, String serviciosUtilizados, String costoVuelo) {
        this.numVuelo = numVuelo;
        this.aerolinea = aerolinea;
        this.paisProcendencia = paisProcendencia;
        this.cantPasajeros = cantPasajeros;
        this.serviciosUtilizados = serviciosUtilizados;
        this.costoVuelo = costoVuelo;
    }

    //Getters
    public String getNumVuelo() {
        return numVuelo;
    }

    public String getAerolinea() {
        return aerolinea;
    }

    public String getPaisProcendencia() {
        return paisProcendencia;
    }

    public String getCantPasajeros() {
        return cantPasajeros;
    }

    public String getServiciosUtilizados() {
        return serviciosUtilizados;
    }

    public String getCostoVuelo() {
        return costoVuelo;
    }

    //Setters
    public void setNumVuelo(String numVuelo) {
        this.numVuelo = numVuelo;
    }

    public void setAerolinea(String aerolinea) {
        this.aerolinea = aerolinea;
    }

    public void setPaisProcendencia(String paisProcendencia) {
        this.paisProcendencia = paisProcendencia;
    }

    public void setCantPasajeros(String cantPasajeros) {
        this.cantPasajeros = cantPasajeros;
    }

    public void setServiciosUtilizados(String serviciosUtilizados) {
        this.serviciosUtilizados = serviciosUtilizados;
    }

    public void setCostoVuelo(String costoVuelo) {
        this.costoVuelo = costoVuelo;
    }

}
