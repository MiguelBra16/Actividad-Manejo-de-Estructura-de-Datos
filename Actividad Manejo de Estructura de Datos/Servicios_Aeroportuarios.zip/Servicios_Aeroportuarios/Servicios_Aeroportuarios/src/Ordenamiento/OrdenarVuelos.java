package Ordenamiento;

import java.util.Comparator;

public class OrdenarVuelos implements Comparator<Double>{
    @Override
    public int compare(Double a, Double b){
        return Double.compare(a, b);
    }
}
