package Formularios;

import Entidades.Aerolinea;
import Entidades.Vuelo;
import Ordenamiento.OrdenarVuelos;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class frm_Servicios extends javax.swing.JFrame {

    //
    private Double e;
    private double maximoGlobal, menorGlobal, promedioGlobal, totalGlobal, vuelosRegistrados;
    private double primerCuar, segundoCuar, tercerCuar, cuartoCuar;
   
    DecimalFormat df = new DecimalFormat("#.00");
    //
    private ArrayList<Aerolinea> lAerolineas;
    ArrayList<Double>lCostoVuelos;
    Aerolinea aerolinea;
    Vuelo vuelo;
    private double totalVuelo;
    DefaultTableModel modeloTabla;
    String arrowTablaGlobal[];

    public frm_Servicios() {
        initComponents();
        this.startFrame();
        this.totalVuelo = 0;
        this.iniciarListaAerolineas();
        this.maximoGlobal = 0;
        this.vuelosRegistrados = 0;
        this.menorGlobal = 5500;
        this.promedioGlobal = 0;
        this.totalGlobal = 0;
        this.lCostoVuelos = new ArrayList<>();
    }

    private void startFrame() {
        this.setEnabled(true);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setTitle("Aeropuerto Internacional de El Salvador");
    }

    private void iniciarListaAerolineas() {
        this.lAerolineas = new ArrayList<>();
        this.aerolinea = new Aerolinea("Aeromexico");
        this.lAerolineas.add(aerolinea);
        this.aerolinea = new Aerolinea("Avianca");
        this.lAerolineas.add(aerolinea);
        this.aerolinea = new Aerolinea("Copa Airlines");
        this.lAerolineas.add(aerolinea);
        this.aerolinea = new Aerolinea("Delta");
        this.lAerolineas.add(aerolinea);
    }

    @SuppressWarnings("unchecked")
     // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
     private void initComponents() {

          jPanel1 = new javax.swing.JPanel();
          jLabel1 = new javax.swing.JLabel();
          jLabel2 = new javax.swing.JLabel();
          cboAerolineas = new javax.swing.JComboBox<>();
          jLabel3 = new javax.swing.JLabel();
          ffNumVuelo = new javax.swing.JFormattedTextField();
          jLabel4 = new javax.swing.JLabel();
          jLabel5 = new javax.swing.JLabel();
          chbAterrizaje = new javax.swing.JCheckBox();
          chbEmbarque = new javax.swing.JCheckBox();
          chbDesembarque = new javax.swing.JCheckBox();
          chbEstacionamiento = new javax.swing.JCheckBox();
          chbTelescopicos = new javax.swing.JCheckBox();
          chbPasajeros = new javax.swing.JCheckBox();
          jLabel6 = new javax.swing.JLabel();
          spnCantidadPasajeros = new javax.swing.JSpinner();
          jLabel7 = new javax.swing.JLabel();
          txtTotal = new javax.swing.JTextField();
          btnRegistrar = new javax.swing.JButton();
          cboPaises = new javax.swing.JComboBox<>();
          jpMid = new javax.swing.JPanel();
          jLabel8 = new javax.swing.JLabel();
          cboAerolineasFiltrar = new javax.swing.JComboBox<>();
          jScrollPane2 = new javax.swing.JScrollPane();
          jtVuelosPorAerolinea = new javax.swing.JTable();
          jScrollPane3 = new javax.swing.JScrollPane();
          jtVuelosTotalesDia = new javax.swing.JTable();
          jLabel9 = new javax.swing.JLabel();
          jLabel10 = new javax.swing.JLabel();
          jLabel11 = new javax.swing.JLabel();
          txtMaximoGlobal = new javax.swing.JTextField();
          jLabel12 = new javax.swing.JLabel();
          txtMinimoGlobal = new javax.swing.JTextField();
          jLabel13 = new javax.swing.JLabel();
          txtPromedioGlobal = new javax.swing.JTextField();
          txtTotalGlobal = new javax.swing.JTextField();
          jLabel14 = new javax.swing.JLabel();
          jScrollPane1 = new javax.swing.JScrollPane();
          jtCuartil1 = new javax.swing.JTable();
          jScrollPane4 = new javax.swing.JScrollPane();
          jtCuartil3 = new javax.swing.JTable();
          jScrollPane5 = new javax.swing.JScrollPane();
          jtCuartil2 = new javax.swing.JTable();
          jScrollPane6 = new javax.swing.JScrollPane();
          jtCuartil4 = new javax.swing.JTable();
          jLabel15 = new javax.swing.JLabel();
          jLabel16 = new javax.swing.JLabel();
          jLabel17 = new javax.swing.JLabel();
          jLabel18 = new javax.swing.JLabel();

          setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

          jPanel1.setPreferredSize(new java.awt.Dimension(300, 619));

          jLabel1.setFont(new java.awt.Font("Liberation Sans", 1, 22)); // NOI18N
          jLabel1.setText("-----Registrar Vuelo-----");

          jLabel2.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          jLabel2.setText("Aerolinea");

          cboAerolineas.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          cboAerolineas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aeromexico", "Avianca", "Copa Airlines", "Delta" }));

          jLabel3.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          jLabel3.setText("Núm. De Vuelo");

          try {
               ffNumVuelo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###")));
          } catch (java.text.ParseException ex) {
               ex.printStackTrace();
          }
          ffNumVuelo.setFont(new java.awt.Font("Liberation Sans", 0, 14)); // NOI18N

          jLabel4.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
          jLabel4.setText("Servicios Aeroportuarios");

          jLabel5.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          jLabel5.setText("País de Procendencia");

          chbAterrizaje.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          chbAterrizaje.setText("Aterrizaje");
          chbAterrizaje.addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                    chbAterrizajeMouseClicked(evt);
               }
          });

          chbEmbarque.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          chbEmbarque.setText("Plataforma de Embarque");
          chbEmbarque.addActionListener(new java.awt.event.ActionListener() {
               public void actionPerformed(java.awt.event.ActionEvent evt) {
                    chbEmbarqueActionPerformed(evt);
               }
          });

          chbDesembarque.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          chbDesembarque.setText("Plataforma de Desembarque");
          chbDesembarque.addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                    chbDesembarqueMouseClicked(evt);
               }
          });

          chbEstacionamiento.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          chbEstacionamiento.setText("Plataforma de Estacionamiento");
          chbEstacionamiento.addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                    chbEstacionamientoMouseClicked(evt);
               }
          });

          chbTelescopicos.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          chbTelescopicos.setText("Pasillos Telescópicos");
          chbTelescopicos.addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                    chbTelescopicosMouseClicked(evt);
               }
          });

          chbPasajeros.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          chbPasajeros.setText("Revisión Pasajeros y equipaje (Mano)");
          chbPasajeros.addMouseListener(new java.awt.event.MouseAdapter() {
               public void mouseClicked(java.awt.event.MouseEvent evt) {
                    chbPasajerosMouseClicked(evt);
               }
          });

          jLabel6.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          jLabel6.setText("Cantidad de Pasajeros");

          spnCantidadPasajeros.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          spnCantidadPasajeros.setModel(new javax.swing.SpinnerNumberModel(1, 1, 583, 1));

          jLabel7.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          jLabel7.setText("Total");

          txtTotal.setEditable(false);
          txtTotal.setFont(new java.awt.Font("Liberation Sans", 0, 14)); // NOI18N
          txtTotal.setText("$ 0.0");

          btnRegistrar.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          btnRegistrar.setText("Registrar");
          btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
               public void actionPerformed(java.awt.event.ActionEvent evt) {
                    btnRegistrarActionPerformed(evt);
               }
          });

          cboPaises.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          cboPaises.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Argentina", "Belice", "Brazil", "Canada", "Chile", "Colombia", "Costa Rica", "Estados Unidos", "Guatemala", "Mexíco", "Nicaragua", "Panama", "Perú" }));

          javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
          jPanel1.setLayout(jPanel1Layout);
          jPanel1Layout.setHorizontalGroup(
               jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(jLabel2)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(cboAerolineas, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(chbDesembarque))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(chbEstacionamiento))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(chbTelescopicos))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(chbEmbarque, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(chbPasajeros))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(chbAterrizaje))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addGap(35, 35, 35)
                              .addComponent(jLabel4))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addComponent(jLabel7)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addGap(86, 86, 86)
                              .addComponent(btnRegistrar))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                   .addComponent(cboPaises, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                   .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addContainerGap()
                              .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                   .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ffNumVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                                   .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(spnCantidadPasajeros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                         .addGroup(jPanel1Layout.createSequentialGroup()
                              .addGap(34, 34, 34)
                              .addComponent(jLabel1)))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
          );
          jPanel1Layout.setVerticalGroup(
               jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1)
                    .addGap(32, 32, 32)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                         .addComponent(jLabel2)
                         .addComponent(cboAerolineas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                         .addComponent(jLabel3)
                         .addComponent(ffNumVuelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(jLabel5)
                    .addGap(9, 9, 9)
                    .addComponent(cboPaises, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                         .addComponent(jLabel6)
                         .addComponent(spnCantidadPasajeros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(39, 39, 39)
                    .addComponent(jLabel4)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(chbAterrizaje)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(chbEmbarque)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(chbDesembarque)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(chbEstacionamiento)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(chbTelescopicos)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(chbPasajeros)
                    .addGap(48, 48, 48)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                         .addComponent(jLabel7)
                         .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(btnRegistrar)
                    .addContainerGap(99, Short.MAX_VALUE))
          );

          getContentPane().add(jPanel1, java.awt.BorderLayout.LINE_START);

          jpMid.setBackground(javax.swing.UIManager.getDefaults().getColor("Button.highlight"));

          jLabel8.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          jLabel8.setText("Mostrar Vuelos De");

          cboAerolineasFiltrar.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          cboAerolineasFiltrar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Aeromexico", "Avianca", "Copa Airlines", "Delta" }));
          cboAerolineasFiltrar.addActionListener(new java.awt.event.ActionListener() {
               public void actionPerformed(java.awt.event.ActionEvent evt) {
                    cboAerolineasFiltrarActionPerformed(evt);
               }
          });

          jtVuelosPorAerolinea.setModel(new javax.swing.table.DefaultTableModel(
               new Object [][] {

               },
               new String [] {
                    "Núm. Vuelo", "País Procedencia", "Cant. Pasajeros", "Servicios Utilizados", "Costo"
               }
          ) {
               boolean[] canEdit = new boolean [] {
                    false, false, false, false, false
               };

               public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return canEdit [columnIndex];
               }
          });
          jScrollPane2.setViewportView(jtVuelosPorAerolinea);
          if (jtVuelosPorAerolinea.getColumnModel().getColumnCount() > 0) {
               jtVuelosPorAerolinea.getColumnModel().getColumn(0).setResizable(false);
               jtVuelosPorAerolinea.getColumnModel().getColumn(1).setResizable(false);
               jtVuelosPorAerolinea.getColumnModel().getColumn(2).setResizable(false);
               jtVuelosPorAerolinea.getColumnModel().getColumn(3).setResizable(false);
               jtVuelosPorAerolinea.getColumnModel().getColumn(4).setResizable(false);
          }

          jtVuelosTotalesDia.setModel(new javax.swing.table.DefaultTableModel(
               new Object [][] {

               },
               new String [] {
                    "Núm. Vuelo", "Aerolinea", "País Procedencia", "Cant. Pasajeros", "Servicios Utilizados", "Costo"
               }
          ) {
               boolean[] canEdit = new boolean [] {
                    false, false, false, false, false, false
               };

               public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return canEdit [columnIndex];
               }
          });
          jScrollPane3.setViewportView(jtVuelosTotalesDia);
          if (jtVuelosTotalesDia.getColumnModel().getColumnCount() > 0) {
               jtVuelosTotalesDia.getColumnModel().getColumn(0).setResizable(false);
               jtVuelosTotalesDia.getColumnModel().getColumn(1).setResizable(false);
               jtVuelosTotalesDia.getColumnModel().getColumn(2).setResizable(false);
               jtVuelosTotalesDia.getColumnModel().getColumn(3).setResizable(false);
               jtVuelosTotalesDia.getColumnModel().getColumn(4).setResizable(false);
               jtVuelosTotalesDia.getColumnModel().getColumn(5).setResizable(false);
          }

          jLabel9.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          jLabel9.setText("Vuelos Registrados el día de Hoy");

          jLabel10.setFont(new java.awt.Font("Liberation Sans", 1, 16)); // NOI18N
          jLabel10.setText("Estadisticas:");

          jLabel11.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          jLabel11.setText("Máximo");

          txtMaximoGlobal.setEditable(false);
          txtMaximoGlobal.setFont(new java.awt.Font("Liberation Sans", 0, 12)); // NOI18N
          txtMaximoGlobal.setText("$ 0.0");

          jLabel12.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          jLabel12.setText("Minimo");

          txtMinimoGlobal.setEditable(false);
          txtMinimoGlobal.setFont(new java.awt.Font("Liberation Sans", 0, 12)); // NOI18N
          txtMinimoGlobal.setText("$ 0.0");

          jLabel13.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          jLabel13.setText("Promedio");

          txtPromedioGlobal.setEditable(false);
          txtPromedioGlobal.setFont(new java.awt.Font("Liberation Sans", 0, 12)); // NOI18N
          txtPromedioGlobal.setText("$ 0.0");

          txtTotalGlobal.setEditable(false);
          txtTotalGlobal.setFont(new java.awt.Font("Liberation Sans", 0, 12)); // NOI18N
          txtTotalGlobal.setText("$ 0.0");

          jLabel14.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
          jLabel14.setText("Total");

          jtCuartil1.setModel(new javax.swing.table.DefaultTableModel(
               new Object [][] {

               },
               new String [] {
                    "Núm Vuelo", "Costo"
               }
          ) {
               boolean[] canEdit = new boolean [] {
                    false, false
               };

               public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return canEdit [columnIndex];
               }
          });
          jScrollPane1.setViewportView(jtCuartil1);
          if (jtCuartil1.getColumnModel().getColumnCount() > 0) {
               jtCuartil1.getColumnModel().getColumn(0).setResizable(false);
               jtCuartil1.getColumnModel().getColumn(1).setResizable(false);
          }

          jtCuartil3.setModel(new javax.swing.table.DefaultTableModel(
               new Object [][] {

               },
               new String [] {
                    "Núm Vuelo", "Costo"
               }
          ) {
               boolean[] canEdit = new boolean [] {
                    false, false
               };

               public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return canEdit [columnIndex];
               }
          });
          jScrollPane4.setViewportView(jtCuartil3);
          if (jtCuartil3.getColumnModel().getColumnCount() > 0) {
               jtCuartil3.getColumnModel().getColumn(0).setResizable(false);
               jtCuartil3.getColumnModel().getColumn(1).setResizable(false);
          }

          jtCuartil2.setModel(new javax.swing.table.DefaultTableModel(
               new Object [][] {

               },
               new String [] {
                    "Núm Vuelo", "Costo"
               }
          ) {
               boolean[] canEdit = new boolean [] {
                    false, false
               };

               public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return canEdit [columnIndex];
               }
          });
          jScrollPane5.setViewportView(jtCuartil2);
          if (jtCuartil2.getColumnModel().getColumnCount() > 0) {
               jtCuartil2.getColumnModel().getColumn(0).setResizable(false);
               jtCuartil2.getColumnModel().getColumn(1).setResizable(false);
          }

          jtCuartil4.setModel(new javax.swing.table.DefaultTableModel(
               new Object [][] {

               },
               new String [] {
                    "Núm Vuelo", "Costo"
               }
          ) {
               boolean[] canEdit = new boolean [] {
                    false, false
               };

               public boolean isCellEditable(int rowIndex, int columnIndex) {
                    return canEdit [columnIndex];
               }
          });
          jScrollPane6.setViewportView(jtCuartil4);
          if (jtCuartil4.getColumnModel().getColumnCount() > 0) {
               jtCuartil4.getColumnModel().getColumn(0).setResizable(false);
               jtCuartil4.getColumnModel().getColumn(1).setResizable(false);
          }

          jLabel15.setText("Primer Cuartil");

          jLabel16.setText("Segundo cuartil");

          jLabel17.setText("Tercer Cuartil");

          jLabel18.setText("Cuarto cuartil");

          javax.swing.GroupLayout jpMidLayout = new javax.swing.GroupLayout(jpMid);
          jpMid.setLayout(jpMidLayout);
          jpMidLayout.setHorizontalGroup(
               jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 938, Short.MAX_VALUE)
               .addComponent(jScrollPane2)
               .addGroup(jpMidLayout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                         .addGroup(jpMidLayout.createSequentialGroup()
                              .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                   .addGroup(jpMidLayout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cboAerolineasFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                                   .addComponent(jLabel9)
                                   .addGroup(jpMidLayout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtMaximoGlobal, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtMinimoGlobal, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPromedioGlobal, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtTotalGlobal, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))
                              .addContainerGap(152, Short.MAX_VALUE))
                         .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpMidLayout.createSequentialGroup()
                              .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                   .addGroup(jpMidLayout.createSequentialGroup()
                                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE))
                                   .addGroup(jpMidLayout.createSequentialGroup()
                                        .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                             .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                                             .addComponent(jLabel17))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                             .addComponent(jLabel18)
                                             .addComponent(jLabel16)
                                             .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE))))
                              .addGap(65, 65, 65))
                         .addGroup(jpMidLayout.createSequentialGroup()
                              .addComponent(jLabel15)
                              .addGap(0, 0, Short.MAX_VALUE))))
          );
          jpMidLayout.setVerticalGroup(
               jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
               .addGroup(jpMidLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel9)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                         .addComponent(jLabel8)
                         .addComponent(cboAerolineasFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                         .addGroup(jpMidLayout.createSequentialGroup()
                              .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                   .addGroup(jpMidLayout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(txtTotalGlobal))
                                   .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel10)
                                        .addComponent(jLabel11)
                                        .addComponent(txtMaximoGlobal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel12)
                                        .addComponent(txtMinimoGlobal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel13)
                                        .addComponent(txtPromedioGlobal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel14)))
                              .addGap(18, 18, Short.MAX_VALUE)
                              .addComponent(jLabel15)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                         .addGroup(jpMidLayout.createSequentialGroup()
                              .addGap(0, 0, Short.MAX_VALUE)
                              .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                              .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                              .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                         .addComponent(jLabel17)
                         .addComponent(jLabel18))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jpMidLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                         .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                         .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap())
          );

          getContentPane().add(jpMid, java.awt.BorderLayout.CENTER);

          pack();
     }// </editor-fold>//GEN-END:initComponents
    
     public void obtenerCuartiles(){
        OrdenarVuelos OV = new OrdenarVuelos();
        this.lCostoVuelos.sort(OV);
        this.e = this.lCostoVuelos.get(this.lCostoVuelos.size()-1);
        this.primerCuar = e*0.25;
        System.out.println(this.primerCuar);
        this.segundoCuar = e*0.50;
        System.out.println(this.segundoCuar);
        this.tercerCuar = e*0.75;
        System.out.println(this.tercerCuar);
        this.cuartoCuar = e*1;
        System.out.println(this.cuartoCuar);
    } 
    private void chbAterrizajeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chbAterrizajeMouseClicked
        if (this.chbAterrizaje.isSelected()) {
            this.totalVuelo += 153.5;
        } else {
            this.totalVuelo -= 153.5;
        }
        this.actualizarTotalTxt();
    }//GEN-LAST:event_chbAterrizajeMouseClicked

    private void chbEmbarqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chbEmbarqueActionPerformed
        if (this.chbEmbarque.isSelected()) {
            this.totalVuelo += 174.5;
        } else {
            this.totalVuelo -= 174.5;
        }
        this.actualizarTotalTxt();
    }//GEN-LAST:event_chbEmbarqueActionPerformed

    private void chbDesembarqueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chbDesembarqueMouseClicked
        if (this.chbDesembarque.isSelected()) {
            this.totalVuelo += 180.5;
        } else {
            this.totalVuelo -= 180.5;
        }
        this.actualizarTotalTxt();
    }//GEN-LAST:event_chbDesembarqueMouseClicked

    private void chbEstacionamientoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chbEstacionamientoMouseClicked
        if (this.chbEstacionamiento.isSelected()) {
            this.totalVuelo += 55;
        } else {
            this.totalVuelo -= 55;
        }
        this.actualizarTotalTxt();
    }//GEN-LAST:event_chbEstacionamientoMouseClicked

    private void chbTelescopicosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chbTelescopicosMouseClicked
        if (this.chbTelescopicos.isSelected()) {
            this.totalVuelo += 412;
        } else {
            this.totalVuelo -= 412;
        }
        this.actualizarTotalTxt();
    }//GEN-LAST:event_chbTelescopicosMouseClicked

    private void chbPasajerosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_chbPasajerosMouseClicked
        if (this.chbPasajeros.isSelected()) {
            this.totalVuelo += 8 * (int) this.spnCantidadPasajeros.getValue();
        } else {
            this.totalVuelo -= 8 * (int) this.spnCantidadPasajeros.getValue();
        }
        this.actualizarTotalTxt();
    }//GEN-LAST:event_chbPasajerosMouseClicked

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        this.vuelosRegistrados += 1;
        this.lCostoVuelos.add(this.totalVuelo);
        this.agregarDatosTablaGlobal();
        this.realizarEstadisticas();
        this.agregarVueloAerolinea();
        this.actualizarTablaVuelosAerolinea();
        this.obtenerCuartiles();
        this.agregarArrowPrimerCuartil();
        this.agregarArrowSegundoCuartil();
        this.agregarArrowTercerCuartil();
        this.agregarArrowCuartoCuartil();
        this.limpiarCampos();
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void cboAerolineasFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboAerolineasFiltrarActionPerformed
        this.actualizarTablaVuelosAerolinea();
    }//GEN-LAST:event_cboAerolineasFiltrarActionPerformed

    private void actualizarTablaVuelosAerolinea() {
        this.modeloTabla = (DefaultTableModel) this.jtVuelosPorAerolinea.getModel();
        this.modeloTabla.getDataVector().removeAllElements();
        this.modeloTabla.fireTableDataChanged();
        for (int i = 0; i < this.lAerolineas.get(this.cboAerolineasFiltrar.getSelectedIndex()).getlVuelos().size(); i++) {
            String arrowVuelo[] = {this.lAerolineas.get(this.cboAerolineasFiltrar.getSelectedIndex()).lVuelos.get(i).getNumVuelo(),
                this.lAerolineas.get(this.cboAerolineasFiltrar.getSelectedIndex()).lVuelos.get(i).getPaisProcendencia(),
                this.lAerolineas.get(this.cboAerolineasFiltrar.getSelectedIndex()).lVuelos.get(i).getCantPasajeros(),
                this.lAerolineas.get(this.cboAerolineasFiltrar.getSelectedIndex()).lVuelos.get(i).getServiciosUtilizados(),
                this.lAerolineas.get(this.cboAerolineasFiltrar.getSelectedIndex()).lVuelos.get(i).getCostoVuelo()};
            this.modeloTabla.addRow(arrowVuelo);
        }
    }

    private void agregarDatosTablaGlobal() {
        this.modeloTabla = (DefaultTableModel) this.jtVuelosTotalesDia.getModel();
        String arrowTablaGlobal[] = {this.ffNumVuelo.getValue().toString(), this.cboAerolineas.getSelectedItem().toString(), this.cboPaises.getSelectedItem().toString(), this.spnCantidadPasajeros.getValue().toString(),
            "Luego esto", this.txtTotal.getText()};
        this.modeloTabla.addRow(arrowTablaGlobal);
    }
    
    public void agregarArrowPrimerCuartil() {
        System.out.println(this.primerCuar);
        if (this.totalVuelo < this.primerCuar) {
            this.modeloTabla = (DefaultTableModel) this.jtCuartil1.getModel();
            this.modeloTabla.getDataVector().removeAllElements();
            this.modeloTabla.fireTableDataChanged();
            String arrowPrimerCuartil[] = {this.ffNumVuelo.getText().trim().toUpperCase() + "" ,"$" + String.valueOf(totalVuelo)};
            this.modeloTabla.addRow(arrowPrimerCuartil);
        }
    }
    
     public void agregarArrowSegundoCuartil() {
        System.out.println(this.segundoCuar);
        if (this.totalVuelo < this.segundoCuar && this.totalVuelo > this.primerCuar) {
            this.modeloTabla = (DefaultTableModel) this.jtCuartil2.getModel();
            this.modeloTabla.getDataVector().removeAllElements();
            this.modeloTabla.fireTableDataChanged();
            String arrowPrimerCuartil[] = {this.ffNumVuelo.getText().trim().toUpperCase() + " " ,"$" + String.valueOf(totalVuelo)};
            this.modeloTabla.addRow(arrowPrimerCuartil);
        }
    }
     
      public void agregarArrowTercerCuartil() {
        System.out.println(this.tercerCuar);
        if (this.totalVuelo < this.tercerCuar && this.totalVuelo > this.segundoCuar) {
            this.modeloTabla = (DefaultTableModel) this.jtCuartil3.getModel();
            this.modeloTabla.getDataVector().removeAllElements();
            this.modeloTabla.fireTableDataChanged();
            String arrowPrimerCuartil[] = {this.ffNumVuelo.getText().trim().toUpperCase() + " " ,"$" + String.valueOf(totalVuelo)};
            this.modeloTabla.addRow(arrowPrimerCuartil);
        }
    }
      
       public void agregarArrowCuartoCuartil() {
        System.out.println(this.cuartoCuar);
        if (this.totalVuelo > this.tercerCuar) {
            this.modeloTabla = (DefaultTableModel) this.jtCuartil4.getModel();
            this.modeloTabla.getDataVector().removeAllElements();
            this.modeloTabla.fireTableDataChanged();
            String arrowPrimerCuartil[] = {this.ffNumVuelo.getText().trim().toUpperCase() + " " ,"$" + String.valueOf(totalVuelo)};
            this.modeloTabla.addRow(arrowPrimerCuartil);
        }
    }
    private void actualizarTotalTxt() {
        this.txtTotal.setText("$" + this.totalVuelo);
    }

    private void agregarVueloAerolinea() {
        this.vuelo = new Vuelo(this.ffNumVuelo.getValue().toString(), this.cboAerolineas.getSelectedItem().toString(), this.cboPaises.getSelectedItem().toString(), this.spnCantidadPasajeros.getValue().toString(),
                "Luego esto", this.txtTotal.getText());
        this.lAerolineas.get(this.cboAerolineas.getSelectedIndex()).agregarVuelo(vuelo);
    }

    private void realizarEstadisticas() {
        if (this.maximoGlobal < this.totalVuelo) {
            this.maximoGlobal = this.totalVuelo;
            this.txtMaximoGlobal.setText("$ " + this.maximoGlobal);
        }
        if (this.totalVuelo < this.menorGlobal) {
            this.menorGlobal = this.totalVuelo;
        }
        this.totalGlobal += this.totalVuelo;
        this.txtTotalGlobal.setText("$" + this.totalGlobal);
        this.txtMinimoGlobal.setText("$ " + this.menorGlobal);
        this.txtPromedioGlobal.setText("$ " + df.format(this.totalGlobal / this.vuelosRegistrados));
    }

    private void limpiarCampos() {
        this.cboAerolineas.setSelectedIndex(0);
        this.ffNumVuelo.setText("");
        this.cboPaises.setSelectedIndex(0);
        this.spnCantidadPasajeros.setValue(1);
        this.chbAterrizaje.setSelected(false);
        this.chbDesembarque.setSelected(false);
        this.chbEmbarque.setSelected(false);
        this.chbEstacionamiento.setSelected(false);
        this.chbPasajeros.setSelected(false);
        this.chbTelescopicos.setSelected(false);
        this.totalVuelo = 0;
        this.txtTotal.setText("$ 0.0");
    }

     // Variables declaration - do not modify//GEN-BEGIN:variables
     private javax.swing.JButton btnRegistrar;
     private javax.swing.JComboBox<String> cboAerolineas;
     private javax.swing.JComboBox<String> cboAerolineasFiltrar;
     private javax.swing.JComboBox<String> cboPaises;
     private javax.swing.JCheckBox chbAterrizaje;
     private javax.swing.JCheckBox chbDesembarque;
     private javax.swing.JCheckBox chbEmbarque;
     private javax.swing.JCheckBox chbEstacionamiento;
     private javax.swing.JCheckBox chbPasajeros;
     private javax.swing.JCheckBox chbTelescopicos;
     private javax.swing.JFormattedTextField ffNumVuelo;
     private javax.swing.JLabel jLabel1;
     private javax.swing.JLabel jLabel10;
     private javax.swing.JLabel jLabel11;
     private javax.swing.JLabel jLabel12;
     private javax.swing.JLabel jLabel13;
     private javax.swing.JLabel jLabel14;
     private javax.swing.JLabel jLabel15;
     private javax.swing.JLabel jLabel16;
     private javax.swing.JLabel jLabel17;
     private javax.swing.JLabel jLabel18;
     private javax.swing.JLabel jLabel2;
     private javax.swing.JLabel jLabel3;
     private javax.swing.JLabel jLabel4;
     private javax.swing.JLabel jLabel5;
     private javax.swing.JLabel jLabel6;
     private javax.swing.JLabel jLabel7;
     private javax.swing.JLabel jLabel8;
     private javax.swing.JLabel jLabel9;
     private javax.swing.JPanel jPanel1;
     private javax.swing.JScrollPane jScrollPane1;
     private javax.swing.JScrollPane jScrollPane2;
     private javax.swing.JScrollPane jScrollPane3;
     private javax.swing.JScrollPane jScrollPane4;
     private javax.swing.JScrollPane jScrollPane5;
     private javax.swing.JScrollPane jScrollPane6;
     private javax.swing.JPanel jpMid;
     private javax.swing.JTable jtCuartil1;
     private javax.swing.JTable jtCuartil2;
     private javax.swing.JTable jtCuartil3;
     private javax.swing.JTable jtCuartil4;
     private javax.swing.JTable jtVuelosPorAerolinea;
     private javax.swing.JTable jtVuelosTotalesDia;
     private javax.swing.JSpinner spnCantidadPasajeros;
     private javax.swing.JTextField txtMaximoGlobal;
     private javax.swing.JTextField txtMinimoGlobal;
     private javax.swing.JTextField txtPromedioGlobal;
     private javax.swing.JTextField txtTotal;
     private javax.swing.JTextField txtTotalGlobal;
     // End of variables declaration//GEN-END:variables
}
